
import React from 'react';
import DetailScreen from '../screens/DetailScreen';

export default function Detail() {
  return <DetailScreen />;
}
