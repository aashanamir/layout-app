
import React from 'react';
import CategoryScreen from '../screens/CategoryScreen';

export default function Category() {
  return <CategoryScreen />;
}
